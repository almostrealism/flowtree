package org.almostrealism.birst.util;

public class Node<T> {
	protected T parent, left, right;
	
	public Node(T parent) {
		this.parent = parent;
	}
}
