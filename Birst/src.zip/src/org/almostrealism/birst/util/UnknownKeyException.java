package org.almostrealism.birst.util;

public class UnknownKeyException extends RuntimeException {

}
